package com.example.barbershop;

public class Rezervacije {
    public int id;
    public  int dan;
    public int mjesec;
    public int godina;
    public int terminid;
    public String termin;
}
