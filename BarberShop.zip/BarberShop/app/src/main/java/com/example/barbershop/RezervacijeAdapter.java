package com.example.barbershop;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.List;

public  class RezervacijeAdapter extends RecyclerView.Adapter<RezervacijeAdapter.MyViewHolder> {
    private Activity context;
    private List<Rezervacije> mDataset;
    private SharedPreferences sharedPref;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView textView;

        public MyViewHolder(FrameLayout v) {
            super(v);
            textView = v.findViewById(R.id.textView);
        }
    }

    public RezervacijeAdapter(Activity context, List<Rezervacije> myDataset) {
        this.context = context;
        mDataset = myDataset;

    }


    @Override
    public RezervacijeAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                          int viewType) {
        // create a new view
        FrameLayout v = (FrameLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.listarezervacija, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }



    @Override
    public void onBindViewHolder(RezervacijeAdapter.MyViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        if(mDataset==null){
            holder.textView.setText( "Nemate trenutno aktivnih rezervacija!");

        }
        else {
            final Rezervacije rezv = mDataset.get(position);
            holder.textView.setText("" + rezv.dan + "." + rezv.mjesec + "." + rezv.godina + "\n" + rezv.termin + "h");
            holder.textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Post rezervacije
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case DialogInterface.BUTTON_POSITIVE:
                                    StringRequest request = new StringRequest(Request.Method.DELETE, BuildConfig.SERVER_URL + "/api/rezervacija/" + rezv.id, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            // uspjsno
                                            Intent intent = new Intent(context, MojeRezervacijeActivity.class);

                                            context.startActivity(intent);
                                            context.finish();


                                            Log.d("kina-login-response", response.toString());
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            context.startActivity(new Intent(context, LoginActivity.class));
                                            context.finish();

                                        }
                                    });
                                    Volley.newRequestQueue(context).add(request);


                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setMessage("Da li ste sigurni da želite otkazati rezervaciju?").setPositiveButton("Da", dialogClickListener)
                            .setNegativeButton("Ne", dialogClickListener).show();

                    //   Log.e("kina", "a " + rezv.id);

                }


            });

        }
    }



    @Override
    public int getItemCount() {
        return mDataset.size();
    }

}
