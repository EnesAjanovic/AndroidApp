package com.example.barbershop;

public class RezervacijeFull {

    String termin;
    String korisnik;
    String broj;
}
