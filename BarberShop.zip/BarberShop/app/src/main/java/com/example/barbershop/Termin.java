package com.example.barbershop;

public class Termin {
    public int id;
    public String termin;
}
