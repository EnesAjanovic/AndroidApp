package com.example.barbershop;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class TerminiAdapter extends RecyclerView.Adapter<TerminiAdapter.MyViewHolder> {
    private Activity context;
    private List<Termin> mDataset;
    private  SharedPreferences sharedPref;
    int dan;
    int mjesec;
    int godina;




    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView textView;

        public MyViewHolder(FrameLayout v) {
            super(v);
            textView = v.findViewById(R.id.textView);
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public TerminiAdapter(Activity context, List<Termin> myDataset, int dan, int mjesec, int godina) {
        this.context = context;
        mDataset = myDataset;
        this.dan=dan;
        this.mjesec=mjesec;
        this.godina=godina;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public TerminiAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                          int viewType) {

        FrameLayout v = (FrameLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.listatermina, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @SuppressLint("ResourceType")
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        final Termin termin = mDataset.get(position);
        holder.textView.setText(termin.termin);
        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Post rezervacije
                sharedPref = context.getSharedPreferences("kina", Context.MODE_PRIVATE);

                int id = sharedPref.getInt("id", 0);


                Log.e("kina", "a " + id);
                JSONObject jsonObject=new JSONObject();
                try {
                    jsonObject.put("terminId", termin.id);
                    jsonObject.put("userId",id);
                    jsonObject.put("dan",dan);
                    jsonObject.put("mjesec",(mjesec+1));
                    jsonObject.put("godina",godina);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, BuildConfig.SERVER_URL + "/api/rezervacija", jsonObject, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // uspjsno
                        Intent intent = new Intent(context, UspjesnoActivity.class);

                        context.startActivity(intent);
                        context.finish();

                        Log.d("kina-login-response", response.toString());
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(context);
                        dlgAlert.setMessage("Već imate rezervisan termin na ovaj datum!");
                        dlgAlert.setTitle("BarberShop");
                        dlgAlert.setPositiveButton("OK", null);
                        dlgAlert.setCancelable(true);
                        dlgAlert.create().show();



                    }
                });
                Volley.newRequestQueue(context).add(request);
            }


        });


    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
// ...